from pydantic import BaseModel, ConfigDict
from typing import Optional


class UsuarioCrear(BaseModel):

    id_rol: int
    nombre: str
    apellido: Optional[str] = None
    usuario: str
    password: str


class UsuarioActualizar(BaseModel):

    id_rol: Optional[int] = None
    nombre: Optional[str] = None
    apellido: Optional[str] = None
    usuario: Optional[str] = None
    password: Optional[str] = None


class UsuarioRespuesta(BaseModel):

    model_config = ConfigDict(from_attributes=True)

    id_usuario: int
    id_rol: int
    nombre: str
    apellido: Optional[str]
    usuario: str
    estado: str