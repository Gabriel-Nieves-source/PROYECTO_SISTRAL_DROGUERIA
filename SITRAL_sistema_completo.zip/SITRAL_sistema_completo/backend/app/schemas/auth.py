from pydantic import BaseModel


class LoginRequest(BaseModel):

    usuario: str
    password: str


class LoginResponse(BaseModel):

    success: bool
    message: str
    id_usuario: int
    usuario: str
    nombre: str
    rol: str
    access_token: str
    token_type: str