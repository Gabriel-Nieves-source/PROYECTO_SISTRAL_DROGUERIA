from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.database import engine
from app.routers import auth
from app.routers import usuarios
from app.routers import proveedores
from app.routers import medicamentos
from app.routers import lotes
from app.routers import facturas
from app.routers import alertas
from app.routers import dashboard


app = FastAPI(

    title="SITRAL API",

    description="Sistema de Trazabilidad y Control por Lotes para Droguerías",

    version="1.0.0"
)

# Habilitado para que la aplicación web (sitral-web) pueda consumir la API
# desde otro origen (otro puerto o la IP del computador en red local).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(
    auth.router
)

app.include_router(
    usuarios.router
)

app.include_router(
    proveedores.router
)

app.include_router(
    medicamentos.router
)

app.include_router(
    lotes.router
)

app.include_router(
    facturas.router
)

app.include_router(
    alertas.router
)

app.include_router(
    dashboard.router
)


@app.get("/")
def inicio():

    return {

        "success": True,

        "message": "API SITRAL funcionando correctamente"

    }


@app.get("/health")
def health():

    try:

        with engine.connect() as connection:

            connection.execute(
                text("SELECT 1")
            )

        return {

            "success": True,

            "api": "OK",

            "database": "OK"

        }

    except Exception as error:

        return {

            "success": False,

            "api": "OK",

            "database": "ERROR",

            "detail": str(error)

        }