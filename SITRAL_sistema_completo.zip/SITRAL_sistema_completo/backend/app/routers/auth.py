from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pwdlib import PasswordHash

from app.database import get_db
from app.models.usuario import Usuario
from app.schemas.auth import LoginRequest, LoginResponse
from app.security import crear_token, obtener_usuario_actual


router = APIRouter(
    prefix="/auth",
    tags=["Autenticación"]
)


password_hash = PasswordHash.recommended()


@router.post(
    "/login",
    response_model=LoginResponse
)
def login(
    datos: LoginRequest,
    db: Session = Depends(get_db)
):

    usuario = db.query(Usuario).filter(
        Usuario.usuario == datos.usuario
    ).first()


    if not usuario:

        raise HTTPException(
            status_code=401,
            detail="Usuario o contraseña incorrectos"
        )


    if not password_hash.verify(
        datos.password,
        usuario.password
    ):

        raise HTTPException(
            status_code=401,
            detail="Usuario o contraseña incorrectos"
        )


    if usuario.estado != "ACTIVO":

        raise HTTPException(
            status_code=403,
            detail="El usuario está inactivo"
        )


    token = crear_token({

        "sub": str(usuario.id_usuario),

        "usuario": usuario.usuario,

        "rol": usuario.rol.nombre

    })


    return {

        "success": True,

        "message": "Inicio de sesión exitoso",

        "id_usuario": usuario.id_usuario,

        "usuario": usuario.usuario,

        "nombre": usuario.nombre,

        "rol": usuario.rol.nombre,

        "access_token": token,

        "token_type": "bearer"
    }


@router.get("/me")
def obtener_perfil(
    usuario_actual: dict = Depends(obtener_usuario_actual)
):

    return {

        "success": True,

        "message": "Token válido",

        "usuario": usuario_actual

    }